package com.example.StudentApi.repository;

import java.util.List;
import java.util.Optional;

import com.example.StudentApi.entity.Project;

public interface ProjectInterface {

	int save(Project project) throws Exception;
	
	Optional<Project> findById(int projectId);
	
	List<Project> findAll();
	
	Optional<Integer> updateProject(int projectId, Project project);

	
}
