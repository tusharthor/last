package com.example.StudentApi.repository;

import java.util.List;
import java.util.Optional;

import com.example.StudentApi.entity.Student;

public interface StudentInterface {

	int save(Student student) throws Exception;
	
	Optional<Student> findById(int studentId);
	
	List<Student> findAll();
}
