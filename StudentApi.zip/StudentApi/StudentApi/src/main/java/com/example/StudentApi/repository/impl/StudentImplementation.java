package com.example.StudentApi.repository.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.StudentApi.entity.Student;
import com.example.StudentApi.repository.StudentInterface;


@Repository
public class StudentImplementation implements StudentInterface{

	private static final String INSERTSTUDENT = "INSERT INTO student (student_id, first_name, last_name, mobile_number, email_id, project_list)"
			+ " VALUES (?,?,?,?,?)";
	private static final String LEFTJOINSTUDENT = "SELECT * FROM student LEFT OUTER JOIN project ON student.project_list = project.project_id and student_id=?";
	private static final String FINDBYID = "SELECT * FROM student WHERE	student_id = ?";
	private static final String CHECKSTUDENTID = "select count(*) from student where student_id=?";
	private static final String FINDALLSTUDENTS = "SELECT * FROM student"; 
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	
	@Override
	public int save(Student student) throws Exception {
		
		return jdbcTemplate.update(INSERTSTUDENT,
				student.getStudentId(), student.getFirstName(), student.getLastName(), student.getMobileNumber(), student.getEmailId()); 
				
	}

		
	@Override
	public Optional<Student> findById(int studentid){
		
		try {

				Student student =  jdbcTemplate.queryForObject(FINDBYID,
						BeanPropertyRowMapper.newInstance(Student.class), studentid);

				return Optional.of(student);
 
		}catch(EmptyResultDataAccessException p) {
			return Optional.empty();
		}
		
				
	}
	
	
	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query( FINDALLSTUDENTS,
				BeanPropertyRowMapper.newInstance(Student.class));
	}

}
