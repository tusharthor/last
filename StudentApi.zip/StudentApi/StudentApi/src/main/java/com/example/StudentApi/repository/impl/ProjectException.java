package com.example.StudentApi.repository.impl;

public class ProjectException extends RuntimeException {
	
	public ProjectException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
